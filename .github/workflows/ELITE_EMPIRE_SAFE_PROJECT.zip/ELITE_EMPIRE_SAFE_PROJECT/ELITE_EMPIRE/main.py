import os
import runpy
import threading
import time

from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout

KV = """
<RunnerUI>:
    orientation: "vertical"
    padding: "18dp"
    spacing: "10dp"

    Label:
        text: "[b]ELITE EMPIRE RUNNER[/b]"
        markup: True
        font_size: "23sp"
        size_hint_y: None
        height: "52dp"

    Label:
        id: status1
        text: "File 1: Waiting"
        size_hint_y: None
        height: "32dp"

    Button:
        text: "START / RESTART FILE 1"
        size_hint_y: None
        height: "48dp"
        on_release: app.start_file1()

    Button:
        text: "STOP FILE 1"
        size_hint_y: None
        height: "48dp"
        on_release: app.stop_file1()

    Label:
        text: "[b]TELEGRAM SETTINGS[/b]"
        markup: True
        size_hint_y: None
        height: "38dp"

    TextInput:
        id: token
        hint_text: "Telegram Bot Token"
        password: True
        multiline: False
        size_hint_y: None
        height: "48dp"

    TextInput:
        id: chat
        hint_text: "Telegram Chat ID"
        multiline: False
        size_hint_y: None
        height: "48dp"

    Button:
        text: "RUN FILE 2 (SEND TEST STATUS)"
        size_hint_y: None
        height: "48dp"
        on_release: app.start_file2()

    Label:
        id: status2
        text: "File 2: Waiting"
        size_hint_y: None
        height: "32dp"

    Label:
        text: "Scripts run only while this app is open. Use Stop to end File 1."
        font_size: "12sp"
"""
class RunnerUI(BoxLayout):
    pass

class EliteRunner(App):
    def build(self):
        self.stop_event = threading.Event()
        self.worker1 = None
        self.worker2 = None
        Builder.load_string(KV)
        self.ui = RunnerUI()
        Clock.schedule_once(lambda dt: self.start_file1(), 0.5)
        return self.ui

    def set_label(self, name, value):
        Clock.schedule_once(lambda dt: setattr(self.ui.ids[name], "text", value), 0)

    def start_file1(self):
        if self.worker1 and self.worker1.is_alive():
            return
        self.stop_event.clear()
        self.worker1 = threading.Thread(target=self.run_file1_loop, daemon=True)
        self.worker1.start()

    def run_file1_loop(self):
        while not self.stop_event.is_set():
            self.set_label("status1", "File 1: Running")
            try:
                runpy.run_path(
                    os.path.join(os.path.dirname(__file__), "file1.py"),
                    init_globals={"STOP_EVENT": self.stop_event}
                )
            except Exception as exc:
                self.set_label("status1", "File 1 error: " + str(exc)[:90])
            if not self.stop_event.is_set():
                self.set_label("status1", "File 1 ended; restarting in 3 sec")
                self.stop_event.wait(3)
        self.set_label("status1", "File 1: Stopped")

    def stop_file1(self):
        self.stop_event.set()
        self.set_label("status1", "File 1: Stop requested")

    def start_file2(self):
        token = self.ui.ids.token.text.strip()
        chat_id = self.ui.ids.chat.text.strip()
        if not token or not chat_id:
            self.set_label("status2", "Enter both token and chat ID")
            return
        if self.worker2 and self.worker2.is_alive():
            self.set_label("status2", "File 2 is already running")
            return
        self.worker2 = threading.Thread(
            target=self.run_file2, args=(token, chat_id), daemon=True
        )
        self.worker2.start()

    def run_file2(self, token, chat_id):
        os.environ["BOT_TOKEN"] = token
        os.environ["CHAT_ID"] = chat_id
        self.set_label("status2", "File 2: Sending test status")
        try:
            runpy.run_path(os.path.join(os.path.dirname(__file__), "file2.py"))
            self.set_label("status2", "File 2: Finished")
        except Exception as exc:
            self.set_label("status2", "File 2 error: " + str(exc)[:90])
        finally:
            os.environ.pop("BOT_TOKEN", None)
            os.environ.pop("CHAT_ID", None)

if __name__ == "__main__":
    EliteRunner().run()
