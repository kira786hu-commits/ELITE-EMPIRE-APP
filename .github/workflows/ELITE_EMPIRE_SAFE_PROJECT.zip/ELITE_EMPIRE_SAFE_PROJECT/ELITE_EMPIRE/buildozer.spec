[app]
title = ELITE EMPIRE RUNNER
package.name = eliteemprunner
package.domain = com.eliteempire
source.dir = .
source.include_exts = py
version = 1.0
requirements = python3,kivy,requests
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 35
android.minapi = 23
android.archs = arm64-v8a

[buildozer]
log_level = 2
warn_on_root = 1
