ELITE EMPIRE RUNNER — SAFE STARTER PROJECT

FILES
- main.py: Kivy app interface.
- file1.py: harmless sample background task with a Stop Event.
- file2.py: sends one Telegram test/status message to the entered chat.
- buildozer.spec: Android packaging configuration.

IMPORTANT
This is a transparent starter template. It does not include the uploaded
Instagram account-enumeration functionality or hidden data collection.
File 1 runs while the app is open. Android may stop background work when
the app is closed or the OS reclaims resources. This project does not
provide hidden persistence, accessibility abuse, device-admin controls,
or automatic permission granting.

For APK builds, use a supported Linux environment (for example a cloud
Linux notebook) with Buildozer. Native Termux builds are not officially
supported by Buildozer.

Telegram:
1. Create/use your own bot.
2. Enter its token and your own chat ID in the app.
3. Press RUN FILE 2 to send a single test message.
Never share your bot token.
